#!/bin/bash

npm install

node index.js
